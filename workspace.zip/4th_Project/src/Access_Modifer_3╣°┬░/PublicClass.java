package Access_Modifer_3��°;

public class PublicClass {
public PublicClass(){
	DefaultClass d = new DefaultClass();
}

public static void main(String[] args) {
	//PrivateClass p = new PrivateClass();
	DefaultClass d = new DefaultClass(); 
}
}

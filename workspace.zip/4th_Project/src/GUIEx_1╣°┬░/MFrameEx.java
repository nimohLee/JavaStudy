package GUIEx_1��°;

import java.awt.Color;

public class MFrameEx extends MFrame{
	
	public MFrameEx() {
		 super(500,400,Color.black);
		 this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new MFrameEx();
	}
}

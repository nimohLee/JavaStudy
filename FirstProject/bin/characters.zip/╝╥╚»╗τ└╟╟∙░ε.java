package characters;

public class 소환사의협곡 {

	public static void main(String[] args) { // 협곡
		
		애쉬 player1 = new 애쉬("RED","원딜","하이눈 애쉬","정복자","점멸,회복");
		
		베이가 player2 = new 베이가("RED","미드","멋진 베이가","정복자","점멸,순간이동");
		다리우스 player3 = new 다리우스("RED","탑","정복자","점멸,점화");
		그레이브즈 player4 = new 그레이브즈("RED","정글","어둠의 수확","점멸,강타");
		유미 player5 = new 유미("RED","서폿","수호자","탈진,점화");
		System.out.println();
		
		애쉬 player6 = new 애쉬("BLUE","원딜","치명적 속도","점멸,회복");
		베이가 player7 = new 베이가("BLUE","미드","어둠의 수확","점멸,순간이동");
		다리우스 player8 = new 다리우스("BLUE","탑","덩크슛 다리우스","정복자","점멸,유체화");
		그레이브즈 player9 = new 그레이브즈("BLUE","정글","마피아 그레이브즈","어둠의 수확","점멸,강타");
		유미 player10 = new 유미("BLUE","서폿","강아지 유미","수호자","점화,회복");
		
		
		
	}
	
	
}
